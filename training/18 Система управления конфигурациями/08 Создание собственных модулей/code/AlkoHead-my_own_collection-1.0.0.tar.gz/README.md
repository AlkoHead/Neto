# my_own_collection

Коллекция Ansible от AlkoHead, содержащая:
- Кастомный модуль `my_own_module` для создания/обновления текстовых файлов.
- Роль `file_creator` для удобного использования модуля.

## Требования

- Ansible 2.10+

## Установка

```bash
ansible-galaxy collection install git+https://github.com/AlkoHead/my_own_collection.git
```

## Использование
### Модуль
```yaml
- name: Создать файл
  AlkoHead.my_own_collection.my_own_module:
    path: /tmp/example.txt
    content: "Привет, Ansible!"
```
### Роль
```yaml
- name: Применить роль
  hosts: localhost
  roles:
    - AlkoHead.my_own_collection.file_creator
```

Параметры роли (в defaults/main.yml):

- file_creator_path: путь к файлу (по умолчанию /tmp/default_file.txt)
- file_creator_content: содержимое файла